package com.example.tlms.chatapp.adapter;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.tlms.chatapp.R;
import com.example.tlms.chatapp.model.Chat;

import java.util.ArrayList;
import java.util.List;

public class chatadapter extends ArrayAdapter<Chat> {

    private Context mContext;
    private List<Chat> chatList;

    public chatadapter(@NonNull Context context,ArrayList<Chat> list) {
        super(context, 0 , list);
        mContext = context;
        chatList = list;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.listitem,parent,false);

        Chat currentChat = chatList.get(position);

        TextView name = (TextView) listItem.findViewById(R.id.name);
        name.setText(currentChat.getNamee());

        TextView msg = (TextView) listItem.findViewById(R.id.msg);
        msg.setText(currentChat.getMsg());

        TextView date = (TextView) listItem.findViewById(R.id.date);
        date.setText(currentChat.getDate());


        return listItem;
    }
}


