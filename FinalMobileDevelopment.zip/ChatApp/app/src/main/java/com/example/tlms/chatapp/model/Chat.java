package com.example.tlms.chatapp.model;

public class Chat {
    String msg,namee,date;

    public Chat() {
    }

    public Chat( String msg, String namee, String date) {

        this.msg = msg;
        this.namee = namee;
        this.date = date;
    }



    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getNamee() {
        return namee;
    }

    public void setNamee(String namee) {
        this.namee = namee;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
