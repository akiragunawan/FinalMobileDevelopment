package com.example.tlms.chatapp;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.tlms.chatapp.model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Register extends AppCompatActivity {

    Button btnreg,btncancel;
    EditText edtusr,edtpss,edtname;
    FirebaseAuth mAuth;
    DatabaseReference mDatabase;
    FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        btnreg = findViewById(R.id.btnreg);
        btncancel = findViewById(R.id.btncancel);
        edtusr = findViewById(R.id.edtuser);
        edtpss = findViewById(R.id.edtpass);
        edtname = findViewById(R.id.edtnama);

        mDatabase = FirebaseDatabase.getInstance().getReference("ChatData/Users");
        mAuth = FirebaseAuth.getInstance();



        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = edtusr.getText().toString().trim();
                String password = edtpss.getText().toString().trim();


            mAuth.createUserWithEmailAndPassword(email,password)
                    .addOnCompleteListener(Register.this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(Register.this, "Register Done", Toast.LENGTH_SHORT).show();
                        FirebaseUser userr = mAuth.getCurrentUser();

                        User user = new User();
                        user.setName(edtname.getText().toString().trim());
                        user.setUsername(edtusr.getText().toString().trim());
                        user.setPassword(edtpss.getText().toString().trim());
                        mDatabase.child(userr.getUid()).setValue(user);

                    }else{
                        Toast.makeText(Register.this, "Register Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            }
        });

        btncancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
