package com.example.tlms.chatapp.model;

public class User {
    String uid,name,Username,password;

    public User() {
    }

    public User(String uid, String name, String username, String password) {
        this.uid = uid;
        this.name = name;
        Username = username;
        this.password = password;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
